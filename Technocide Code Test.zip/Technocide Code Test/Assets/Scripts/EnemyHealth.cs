﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class EnemyHealth : MonoBehaviour
{
    public int StartingHealth = 50;
    public int CurrentHealth;
    bool isDead;
    GameObject enemy;
    // Start is called before the first frame update
    void Awake()
    {
        CurrentHealth = StartingHealth;
        enemy = this.gameObject;
    }

    // Update is called once per frame
    void Update()
    {
       // Debug.Log(CurrentHealth);
    }

    public void TakeDamage(int amount)
    {

        CurrentHealth -= amount;

        if (CurrentHealth <= 0 && !isDead)
        {
            Death();
        }

        void Death()
        {
            isDead = true;
            Destroy(enemy);
        }
    }
}
