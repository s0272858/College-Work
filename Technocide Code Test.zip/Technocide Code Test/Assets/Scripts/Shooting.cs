﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Shooting : MonoBehaviour
{
    [SerializeField]
    [Range(0.1f, 1.5f)]
    private float fireRate = 3.0f;

    [SerializeField]
    [Range(1, 10)]
    private int damage = 10;

    [SerializeField]
    private ParticleSystem fire;
    FOVShootRange fov;
    private float timer;

    public EnemyHealth enemy;
    void Start()
    {
        fire = GetComponent<ParticleSystem>();
    }

  /*  // Update is called once per frame
    void Update()
    {
        
        timer += Time.deltaTime;
        if (timer >= fireRate)
        {
            if (Input.GetButton("Fire1"))
            {
                timer = 0f;
                FireGun();
            }
        }

    }
*/
    void FixedUpdate()
    {
        Vector3 fwd = transform.TransformDirection(Vector3.forward);
        if (Physics.Raycast(transform.position, fwd, 10))
        {
            FireGun();
          
               // hit.collider.gameObject = GameObject.FindGameObjectWithTag("Enemy");
               
               
                   // Debug.Log("4");
                   // enemy.TakeDamage(damage);

                

            

        }
            
    }
    
    private void FireGun()
    {
        print("There is something in front of the object!");
        fire.Play();

        enemy.TakeDamage(damage);
        /*
        fire.Play();

        Debug.Log("1");
        //Ray ray = new Ray(this.transform.position, fwd);
        Debug.Log("2");
        //RaycastHit hitInfo;
               
            Debug.Log("3");
            var CurrentHealth = hitInfo.collider.GetComponent<EnemyHealth>();
            
                if (CurrentHealth != null)
                {
                  Debug.Log("4");
                  CurrentHealth.TakeDamage(damage);

                }
            
        
        */
    }
    
}
