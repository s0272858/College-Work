﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class EnemyAttack : MonoBehaviour
{
    PlayerHealth playerHealth;
    EnemyHealth enemyHealth;
    bool InRange;
    float Timer;

    public float TimeBetweenAttacks = 0.5f;
    public int AttackDamage = 10;
    GameObject player;
    // Start is called before the first frame update
    void Awake()
    {
        player = GameObject.FindGameObjectWithTag("Player");
        playerHealth = player.GetComponent<PlayerHealth>();
        enemyHealth = GetComponent<EnemyHealth>();

    }

    private void OnCollisionEnter(Collision collision)
    {
       
       
        if (collision.gameObject == player)
        {
            InRange = true;
        }
    }

    private void OnCollisionExit(Collision collision)
    {
        
        if (collision.gameObject == player)
        {
            InRange = false;
        }
    }
    // Update is called once per frame
    void Update()
    {
        
        Timer += Time.deltaTime;

        if (Timer >= TimeBetweenAttacks && InRange)
        {
            
            Attack();
        }



    }

    void Attack()
    {
       
        Timer = 0f;

        if (playerHealth.CurrentHealth > 0)
        {
            playerHealth.TakeDamage(AttackDamage);
           
        }
    }
}
