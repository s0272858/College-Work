﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlayerHealth : MonoBehaviour
{
    public int StartingHealth = 100;
    public int CurrentHealth;
    bool isDead;
    //bool Damaged;
    public GameObject player;

    // Start is called before the first frame update
    void Awake()
    {
       
        CurrentHealth = StartingHealth;
        
    }

    // Update is called once per frame
    void Update()
    {
        //Debug.Log(CurrentHealth);
    }

    public void TakeDamage(int amount)
    {
        
        //Damaged = true;
        CurrentHealth -= amount;

        if (CurrentHealth <= 0 && !isDead)
        {
            Death();
        }

        void Death ()
        {
            isDead = true;
            Destroy(player);
        }
    }

}
