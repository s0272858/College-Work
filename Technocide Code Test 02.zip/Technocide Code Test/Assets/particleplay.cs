﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class particleplay : MonoBehaviour
{
    public ParticleSystem particle;


    // Start is called before the first frame update
    void Start()
    {
       
        particle = GetComponent<ParticleSystem>();
        
    }

   
    // Update is called once per frame
    void Update()
    {
        particle.Clear();
        if (Input.GetButtonDown("Fire1"))
        {
            particle.Play();
            Debug.Log("1");
        }
        //else { particle.Pause(); }
        
    }
}
